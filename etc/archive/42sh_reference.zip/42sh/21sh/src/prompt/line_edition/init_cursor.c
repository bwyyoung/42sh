/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   init_cursor.c                                      :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: byoung-w <byoung-w@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2014/09/08 14:49:06 by byoung-w          #+#    #+#             */
/*   Updated: 2014/12/25 07:29:01 by byoung-w         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../../../includes/ft_sh.h"

/*
** allocates a new cursor list element
*/

t_cursor *ft_new_cur(int cursor_index)
{
	t_cursor *new;

	if (!(new = (t_cursor *) malloc(sizeof(t_cursor))))
		fatal("Error: could not allocate env var list elem in ft_new_env");
	new->next = NULL;
	new->prev = NULL;
	new->c_ind = cursor_index;
	new->cursor = FALSE;
	return (new);
}

/*
** pushes a cursor element to the end of a list
*/

void ft_add_cursor(t_cursor **begin_list, int c_ind)
{
	t_cursor *tmp;

	tmp = NULL;
	if (!*begin_list)
	{
		*begin_list = ft_new_cur(c_ind);
		return;
	}
	else
	{
		tmp = *begin_list;
		while (tmp->next)
			tmp = tmp->next;
		tmp->next = ft_new_cur(c_ind);
		tmp->next->prev = tmp;
	}
}

/*
** returns a linked list which will be used to keep track
** of the cursor
** each list element represents a potential cursor position
** the length of the list will be that of the columns
** within the temrinal window
*/

t_cursor *init_cursor(int win_size)
{
	int i;
	t_cursor *cur_list;

	i = 0;
	cur_list = NULL;
	if (!win_size)
		fatal("Error (init_cursor)");
	while (i < win_size)
	{
		ft_add_cursor(&cur_list, i);
		i++;
	}
	return (cur_list);
}
