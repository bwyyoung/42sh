/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   replace_buffer.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: byoung-w <byoung-w@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2014/09/08 14:49:06 by byoung-w          #+#    #+#             */
/*   Updated: 2014/12/25 07:29:01 by byoung-w         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../../../includes/ft_sh.h"

/*
** replaces the buffer linked list
** with the given string.
** each character is going to be another element
** in the linked list
*/

t_buf *replace_buffer(char *string)
{
	int i;
	t_buf *new_buf;
	char key[2];

	i = 0;
	new_buf = NULL;
	if (!string)
		fatal("Error (replace_buf)");
	while (string[i])
	{
		ft_bzero(key, 2);
		key[0] = string[i];
		ft_add_buf(&new_buf, key);
		i++;
	}
	init_buf_ind(new_buf);
	return (new_buf);
}
